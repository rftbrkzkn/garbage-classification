# Garbage Classification ♻️

PyTorch + ResNet18 ile çöp sınıflandırma projesi.

## İçerik
- `train.py`: Eğitim kodları
- `garbage_resnet18.pth`: Eğitilmiş model ağırlıkları
- `requirements.txt`: Gerekli kütüphaneler
